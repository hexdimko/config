#!/bin/bash
/home/webssh/ttyd -c login:pass -p 8080 bash